from plotnine import *
from plotnine.data import mpg


g = (ggplot(mpg) +
 aes(x='manufacturer') +
 geom_bar(size=20) +
 coord_flip() +
 ggtitle('Number of Cars by Make')
 )

print(g)
