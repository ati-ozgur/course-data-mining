library(ggplot2)
g = ggplot(data=diamonds) +
 aes(x=carat,y=price) +
        geom_point()
print(g)
