library(ggplot2)
g = ggplot(data=mpg) +
 aes(x=displ,y=cty) +
    geom_point() +
     facet_wrap(~manufacturer)
print(g)
