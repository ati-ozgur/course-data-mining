library(ggplot2)
g = ggplot(mpg) +
        geom_bar(aes(x = class))
print(g)
