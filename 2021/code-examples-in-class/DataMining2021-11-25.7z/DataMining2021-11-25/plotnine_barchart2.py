from plotnine import *
from plotnine.data import mpg


g = ggplot(mpg) 
g = g + aes(x='manufacturer') 
g = g + geom_bar(size=20) 
g = g + coord_flip() 
g = g + ggtitle('Number of Cars by Make')

print(g)
