from plotnine import *
from plotnine.data import mpg
g = ggplot(mpg) 
g = g + aes(x="displ",y="cty") 
g = g + geom_point() 
g = g + facet_wrap("~manufacturer")
print(g)
