g = ggplot(mpg) +
        geom_density(aes(x = hwy)) +
        theme_minimal()

print(g)
